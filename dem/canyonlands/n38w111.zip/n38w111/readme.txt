National Elevation Dataset (NED) 1 Arc Second Readme


Table of Contents


INTRODUCTION
Part 1: DATA INFORMATION
Part 2: DATA SPECIFICATIONS
PART 3: CONTENTS OF FOLDERS
PART 4: INDEX INFORMATION
PART 5: RESOURCE INFORMATION


INTRODUCTION:

The National Elevation Dataset (NED) is the primary elevation data 
product produced and distributed by the USGS. The NED provides the 
best available public domain raster elevation data of the 
conterminous United States, Alaska, Hawaii, and territorial islands 
in a seamless format.  The NED is derived from diverse source data, 
processed to a common coordinate system and unit of vertical 
measure.  All NED data are distributed in geographic coordinates 
in units of decimal degrees, and in conformance with the North 
American Datum of 1983 (NAD 83).  All elevation values are provided 
in units of meters, and are referenced to the North American 
Vertical Datum of 1988 (NAVD 88) over the conterminous United 
States.  The vertical reference will vary in other areas.  NED data 
are available nationally at resolutions of 1 arc-second (approx. 
30 meters) and 1/3 arc-second (approx. 10 meters), and in limited 
areas at 1/9 arc-second (approx. 3 meters).  At present, the bulk 
of Alaska is only available at a 2 arc-second (approx. 60 meters) 
resolution, owing to a lack of higher resolution source data, 
though some areas are available at resolutions of 1 and 1/3 
arc-second with plans for significant upgrades of the state over 
the next five years.  The NED is updated on a nominal two month 
cycle to integrate newly available, improved elevation source data.

The NED serves as the elevation layer of The National Map, and 
provides basic elevation information for earth science studies and 
mapping applications in the United States.  The data are utilized by 
the scientific and resource management communities for global change 
research, hydrologic modeling, resource monitoring, mapping and 
visualization applications.


Part 1: DATA INFORMATION

Development of the NED required the merging of over 50,000 different 
DEM data files. A processing system was designed to assemble a 
seamless dataset from multiple data sources, resolutions,and 
production methods. Procedures were developed to maintain the 
database with periodic updates and to insure the integration of 
higher resolution elevation data as they become available. A raster 
data model referenced to a geographic grid was used for NED. The 
data model is logically seamless but uses an internal tile structure 
initially selected as a 1- by 1-degree area. The NED dataset 
currently achieves complete national coverage by integrating the 
"best" available data. Even with the "best" available, there could 
be a wide range of source dates and some artifacts in the source
data, such as Level 1 30 DEM's. The system filters production 
artifacts, and performs any necessary datum conversions and 
coordinate transformations. The NED data is only as good as the 
orginal source data. Individual files are appended together into 
the larger tile structure specified for the database.  Edge 
matching, a 6 pixel overlap to ensure no gaps or issues when users 
perform functionslike reprojection to the data, and metadata 
generation are applied lastly in assembling each NED tile.  
NED Homepage is http://ned.usgs.gov


Part 2: DATA SPECIFICATIONS

  Cell size:      	one arc-second
  Data type:      	Floating Point
  Number of rows:    	3612
  Number of columns: 	3612
  Projection:  		Geographic
  Datum:       		NAD83
  Units:       		Decimal Degrees
  Zunits:      		Meters
  Spheroid:    		GRS1980


PART 3: CONTENTS OF FOLDERS

The NED data is stored in 1 x 1 degree tiles in ArcGRID or 
GRIDFLOAT format.  Each tile covers a 1 x 1 degree area of the 
earth's surface.  The naming convention of the folders utilize the 
latitude and longitude coordinates.  The coordinate represents the 
upper left (northwest) corner of the grid.

	Directory Name = The coordinate of the upper left corner 
			 of the grid.  
	Sub Directory = The format, the upper left corner 
			coordinate, and resolution
	Sub Directory = info 
	Metadata file
	Metadata Shapefile
                
     	Examples: 
        
   		n40w110 = North Latitude of 40 degrees and West 
		Longitude of 110 degrees.  This is the upper left 
		corner coordinate. Area within this tile covers N 
		40 degrees top boundary, N39 degrees bottom 
		boundary, W 110 degrees left boundary, W 109 
		degrees right boundary.

		grdn40w110_1 = data is ARCGRID format within the 
		bounding coordinates and is 1 Arc Second 
		Resolution
	OR
          
		floatn40w110_1 = data is GRIDFLOAT format within 
		the bounding coordinates and is 1 Arc Second 
		Resolution, includes the .prj and .hdr files.

		n40w110_1as_meta (.dbf, .shp, .shp.xml, .shx) = 
		data source information of the specific 1 x 1 
		degree area.
                	
		n40w110_meta.txt =  metadata for 1 x 1 degree area.
          
PART 4: INDEX INFORMATION


Indices provided in shape file include:
               
	The complete data source information of the areas that were
	processed into NED.	
		example: ned_meta_200902

	The source data information of the most recent 
	updated areas that were processed into NED.
		example: ned_update_200902

	The 1 x 1 degree tiles updated.
                example: ned_1x1_200902

Indices are available providing data source information of the areas 
that were processed into NED, giving "best available" elevation data.  
The indices can be found at:

	http://ned.usgs.gov/downloads.asp  

The attributes include data source quadname, production method, 
original creation date, resolution, etc.  Descriptions of the 
attribute information is in the NED Data Dictionary.  This can be 
downloaded from:
 
	http://ned.usgs.gov/downloads.asp                    


PART 5: RESOURCE INFORMATION

NED Homepage is:

	http://ned.usgs.gov


Metadata indices are available at:

	http://ned.usgs.gov/downloads.asp


NED Data Dictionary available at:
 
	http://ned.usgs.gov/downloads.asp

NED Release Notes available at:
  
	http://ned.usgs.gov/downloads.asp


To acquire custom downloads go to:

	http://seamless.usgs.gov


To acquire entire datasets via Bulk Data Distribution:

	email bulkdatainfo@usgs.gov


Disclaimer:  Any use of trade, product, or firm names is for 
descriptive purposes only and does not imply endorsement by 
the U. S. Government.    


Publication Date:  March 2009






